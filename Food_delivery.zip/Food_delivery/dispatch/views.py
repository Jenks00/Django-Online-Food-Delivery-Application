from django.shortcuts import render
from django.views import View
from django.contrib.auth.mixins import UserPassesTestMixin, LoginRequiredMixin
from django.utils.timezone import datetime
from customer.models import OrderModel


class Dashboard(LoginRequiredMixin, UserPassesTestMixin, View):
    def get(self, request, *args, **kwargs):
        today = datetime.today()
        orders = OrderModel.objects.filter(
            created_on__year=today.year, created_on__month=today.month, created_on__day=today.day)

        undelivered_orders = []
        shipped_orders = []
        total_revenue = 0
        for order in orders:
            total_revenue += order.get_cart_total

            if order.is_shipped:
                shipped_orders.append(order)
                if not order.is_delivered:
                    undelivered_orders.append(order)

        context = {
            'orders': shipped_orders,
            'orders' : undelivered_orders,
            'total_orders': len(shipped_orders)
        }

        return render(request, 'dispatch/dashboard2.html', context)

    def test_func(self):
        return self.request.user.groups.filter(name='dispatch').exists()


class OrderDetails(LoginRequiredMixin, UserPassesTestMixin, View):
    def get(self, request, pk, *args, **kwargs):
        order = OrderModel.objects.get(pk=pk)
        context = {
            'pk': order.pk,
            'price': order.get_cart_total,
            'order': order
        }

        return render(request, 'dispatch/shipped_details.html', context)

    def post(self, request, pk, *args, **kwargs):
        order = OrderModel.objects.get(pk=pk)
        order.is_delivered = True
        order.save()

        context = {
            'order': order
        }

        return render(request, 'dispatch/shipped_details.html', context)

    def test_func(self):
        return self.request.user.groups.filter(name='dispatch').exists()


def logout(request):
    return render(request, 'account/logout.html')