from django.db import models
from django.contrib.auth.models import User


class Customer(models.Model):
    user = models.OneToOneField(User, null=True, blank=True, on_delete=models.CASCADE)
    name = models.CharField(max_length=200, null=True, blank=True)
    email = models.CharField(max_length=200, null=True, blank=True)
    device = models.CharField(max_length=200, null=True, blank=True)

    def __str__(self):
        if self.name:
            name = self.name
        else:
            name = self.device
        return str(name)


class MenuItem(models.Model):
    name = models.CharField(null=False, blank=False, max_length=100)
    description = models.TextField(null=False, blank=False)
    image = models.ImageField(upload_to='menu_images/')
    price = models.DecimalField(null=True, blank=True, max_digits=7, decimal_places=2)

    def __str__(self):
        return self.name


class OrderModel(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True, blank=True)
    created_on = models.DateTimeField(auto_now_add=True)
    name = models.CharField(max_length=50, null=True, blank=True)
    email = models.CharField(max_length=50, null=True, blank=True)
    address = models.CharField(max_length=50, null=True, blank=True)
    phone_no = models.PositiveIntegerField(default=False, null=True,)
    is_completed = models.BooleanField(default=False)
    is_shipped = models.BooleanField(default=False)
    is_delivered = models.BooleanField(default=False)

    def __str__(self):
        return f'Order: {self.created_on.strftime("%b %d %I: %M %p")}'

    @property
    def get_cart_total(self):
        orderitems = self.orderitem_set.all()
        total = sum([item.get_total for item in orderitems])
        return total

    @property
    def get_cart_items(self):
        orderitems = self.orderitem_set.all()
        total = sum([item.quantity for item in orderitems])
        return total


class OrderItem(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True, blank=True)
    quantity = models.PositiveIntegerField(null=True, blank=True, default=1)
    menuItem = models.ForeignKey(MenuItem, on_delete=models.CASCADE, null=True, blank=True)
    ordermodel = models.ForeignKey(OrderModel, on_delete=models.CASCADE, null=True, blank=True)



    @property
    def get_total(self):
        total = self.menuItem.price * self.quantity
        return total

