from django.shortcuts import render, redirect
from django.views import View
from django.db.models import Q
from .models import *


class Home(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'customer/nav.html')


class About(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'customer/about.html')


class Order(View):
    def get(self, request, *args, **kwargs):
        # get every item from each category
        Menu = MenuItem.objects.all()
        # pass into context
        context = {
                'menu': Menu,
        }
        # render the template
        return render(request, 'customer/order.html', context)


def product(request, pk):
    product = MenuItem.objects.get(id=pk)

    if request.method == 'POST':
        product = MenuItem.objects.get(id=pk)
        # Get user account information
        try:
            customer = request.user.customer
        except:
            device = request.COOKIES['device']
            customer, created = Customer.objects.get_or_create(device=device)
        ordermodel, created = OrderModel.objects.get_or_create(
            customer=customer,
            name='name',
            email='email',
            address='address',
            phone_no=0,
            is_completed=False
        )
        orderItem, created = OrderItem.objects.get_or_create(customer=customer, ordermodel=ordermodel,  menuItem=product)
        orderItem.quantity = request.POST['quantity']
        orderItem.save()
    context = {'product': product, }
    return render(request, 'customer/product.html', context)


def Remove(request, pk):
    try:
        customer = request.user.customer
    except:
        device = request.COOKIES['device']
        customer, created = Customer.objects.get_or_create(device=device)
    ordermodel, created = OrderModel.objects.get_or_create(customer=customer, is_completed=False)
    orderItem, created = OrderItem.objects.filter(id=pk).delete()

    context = {
        'ord': orderItem,
        'order': ordermodel,

    }
    # render the template
    return render(request, 'customer/cart.html', context)


class Ord(View):
    template_name = "cart.html"
    def get(self, request, *args, **kwargs):
        try:
            customer = request.user.customer
        except:
            device = request.COOKIES['device']
            customer, created = Customer.objects.get_or_create(device=device)
        ordermodel, created = OrderModel.objects.get_or_create(customer=customer, is_completed=False
        )

        context = {
            'order': ordermodel,
        }

        # render the template
        return render(request, 'customer/cart.html', context)

    def post(self, request, *args, **kwargs):
        if request.method == 'POST':
            try:
                customer = request.user.customer
            except:
                device = request.COOKIES['device']
                customer, created = Customer.objects.get_or_create(device=device)

            name = request.POST.get('name')
            email = request.POST.get('email')
            address = request.POST.get('address')
            phone_no = request.POST.get('phone_no')

            print(name)
            print(email)
            ordermodel, created = OrderModel.objects.get_or_create(
                customer=customer,
                name='name',
                email='email',
                address='address',
                phone_no=0,
                is_completed=False
            )
            ordermodel.name = name
            ordermodel.email = email
            ordermodel.address = address
            ordermodel.phone_no = phone_no
            ordermodel.is_completed = True
            ordermodel.save()

            context = {
                'order': ordermodel,
            }

            return render(request, 'customer/order_confirmation.html', context)


class OrderConfirmation(View):
    def get(self, request, *args, **kwargs):
        try:
            customer = request.user.customer
        except:
            device = request.COOKIES['device']
            customer, created = Customer.objects.get_or_create(device=device)

        ordermodel, created = OrderModel.objects.get_or_create(
            customer=customer,
            is_completed=False
        )
        ordermodel.is_completed = True
        ordermodel.save()

        context = {
            'order': ordermodel,
        }

        return render(request, 'customer/order_confirmation.html', context)


class Menu(View):
    def get(self, request, *args, **kwargs):
        menu_items = MenuItem.objects.all()

        context = {
            'menu_items': menu_items
        }

        return render(request, 'customer/menu.html', context)


class MenuSearch(View):
    def get(self, request, *args, **kwargs):
        query = self.request.GET.get("q")

        menu_items = MenuItem.objects.filter(
            Q(name__icontains=query) |
            Q(price__icontains=query) |
            Q(description__icontains=query)
        )

        context = {
            'menu_items': menu_items
        }

        return render(request, 'customer/menu.html', context)
