from django.urls import path
from .views import *

urlpatterns = [
	path('cart/', Ord.as_view(), name="cart"),
	path('product/<str:pk>/', product, name="product"),
    path('Remove/<str:pk>/', Remove, name="remove"),
    path('order_confirmation/', OrderConfirmation.as_view(), name="order_confirmation"),
]
