from django.contrib import admin

from .models import MenuItem, OrderModel, OrderItem, Customer

admin.site.register(MenuItem)
admin.site.register(OrderItem)
admin.site.register(OrderModel)
admin.site.register(Customer)