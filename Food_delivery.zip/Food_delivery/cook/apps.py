from django.apps import AppConfig


class CookConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cook'
